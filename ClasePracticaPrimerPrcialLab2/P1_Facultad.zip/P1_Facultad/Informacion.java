package ClasePracticaPrimerPrcialLab2.P1_Facultad;

public interface Informacion {
    abstract int verCantidad();
    abstract String listarContenidos();
}
