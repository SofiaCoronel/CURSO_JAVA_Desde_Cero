package ClasePracticaPrimerPrcialLab2.P1_Facultad;

public class Inicio {
    public static void main(String[] args) {
        Facultad UTN = new Facultad("UTN-FRRE");
    }
}
